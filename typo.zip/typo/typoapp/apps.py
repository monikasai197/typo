from django.apps import AppConfig


class TypoappConfig(AppConfig):
    name = 'typoapp'
