from django.contrib import admin
from django.urls import path
from .views import homepageview,signupuser,userloginview,userwelcomeview,userauthenticate,userlogout,generalpageview,codingpageview,c_pageview,c_plus_pluspageview,pythonpageview,javapageview

urlpatterns = [
    path('',homepageview,name = 'homepage'),
    path('signupuser/',signupuser),
    path('loginuser/',userloginview,name = 'userloginpage'),
    path('user/welcome/',userwelcomeview,name = 'userpage'),
    path('user/authenticate/',userauthenticate),
    path('userlogout/',userlogout),
    path('generalpage/',generalpageview),
    path('codingpage/',codingpageview),
    path('c/',c_pageview),
    path('c++/',c_plus_pluspageview),
    path('python/',pythonpageview),
    path('java/',javapageview),    
]