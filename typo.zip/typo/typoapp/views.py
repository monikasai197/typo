from django.shortcuts import render,redirect
from django.contrib.auth import authenticate,login,logout
from django.contrib import messages
from django.contrib.auth.models import User
from .models import UserModel
# Create your views here.

def homepageview(request):
	return render(request,"typoapp/homepage.html")

def signupuser(request):
	username = request.POST['username']
	password = request.POST['password'] 
	phoneno = request.POST['phoneno']

	# if username already exists
	if User.objects.filter(username = username).exists():
		messages.add_message(request,messages.ERROR,"User already exists. Please LOGIN")
		return redirect('homepage')

	# if username doesnot exist already(everything is fine to create user)
	User.objects.create_user(username = username,password = password).save()
	lastobject = len(User.objects.all())-1
	UserModel(userid = User.objects.all()[int(lastobject)].id,phoneno = phoneno).save()
	messages.add_message(request,messages.ERROR,"User successfully signed. Now please LOGIN")
	return redirect('homepage')

def userloginview(request):
	return render(request,"typoapp/userlogin.html")

def userauthenticate(request):
	username = request.POST['username']
	password = request.POST['password']

	user = authenticate(username = username,password = password)

	# user exists
	if user is not None:
		login(request,user)
		return redirect('userpage')

	# user doesn't exists
	if user is None:
		messages.add_message(request,messages.ERROR,"Invalid credentials")
		return redirect('userloginpage')

def userwelcomeview(request):
	if not request.user.is_authenticated:
		return redirect('userloginpage')
	username = request.user.username
	context = {'username' : username}
	return render(request,'typoapp/userwelcome.html',context)

def userlogout(request):
	logout(request)
	return redirect('homepage')

def generalpageview(request):
	if not request.user.is_authenticated:
		return redirect('userloginpage')
	username = request.user.username
	context = {'username' : username}
	return render(request,'typoapp/generalpage.html',context)

def codingpageview(request):
	if not request.user.is_authenticated:
		return redirect('userloginpage')
	username = request.user.username
	context = {'username' : username}
	return render(request,'typoapp/codingpage.html',context)

def c_pageview(request):
	if not request.user.is_authenticated:
		return redirect('userloginpage')
	username = request.user.username
	context = {'username' : username}
	return render(request,'typoapp/c_page.html',context)

def c_plus_pluspageview(request):
	if not request.user.is_authenticated:
		return redirect('userloginpage')
	username = request.user.username
	context = {'username' : username}
	return render(request,'typoapp/c_plus_pluspage.html',context)

def pythonpageview(request):
	if not request.user.is_authenticated:
		return redirect('userloginpage')
	username = request.user.username
	context = {'username' : username}
	return render(request,'typoapp/pythonpage.html',context)

def javapageview(request):
	if not request.user.is_authenticated:
		return redirect('userloginpage')
	username = request.user.username
	context = {'username' : username}
	return render(request,'typoapp/javapage.html',context)	